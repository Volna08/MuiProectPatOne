import React, { useEffect, useState } from "react";
import {AppHeader} from "./AppHeader/AppHeader.jsx"
import Container from '@mui/material/Container' //возможно, стоит подредактировать стиль 
//вынеся в отдельный файл
import {PostsList} from "./PostsList/index"
import {postData} from "./posts"
import { Divider } from "@mui/material";
import { Footer } from "./Footer/index.jsx";

export const AppMui = () => {
    const [posts, setPosts] = useState(postData)
return (
<>
<AppHeader/>
<Divider />
 <Container> 
   <PostsList postsData={posts}/> 
   </Container> /
<Footer/>
</>
)
}
