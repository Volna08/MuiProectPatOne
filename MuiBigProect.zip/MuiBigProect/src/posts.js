export const postData = [
        {
            "image": "http://dummyimage.com/400x200.png/5fa2dd/ffffff",
            "likes": [],
            "comments": [],
            "tags": [
                "legendary"
            ],
            "isPublished": true,
            "_id": "622bd9e806c7d323b8ae4615",
            "title": "Batman Beyond: Return of the Joker",
            "author": {
                "name": "Иван Иванов",
                "about": "Писатель",
                "avatar": "https://react-learning.ru/image-compressed/default-image.jpg",
                "_id": "622bd81b06c7d323b8ae4614",
                "email": "maxim_91@inbox.ru",
                "__v": 0
            },
            "text": "Change Other Device on Right Upper Arm",
            "created_at": "2022-03-11T23:23:20.891Z",
            "updated_at": "2022-03-11T23:23:20.891Z",
            "__v": 0
        },
        {
            "image": "http://dummyimage.com/400x200.png/ff4444/ffffff",
            "likes": [],
            "comments": [],
            "tags": [
                "peace"
            ],
            "isPublished": true,
            "_id": "622bda5606c7d323b8ae4616",
            "title": "Float",
            "author": {
                "name": "Иван Иванов",
                "about": "Писатель",
                "avatar": "https://react-learning.ru/image-compressed/default-image.jpg",
                "_id": "622bd81b06c7d323b8ae4614",
                "email": "maxim_91@inbox.ru",
                "__v": 0
            },
            "text": "Occlusion of Transverse Colon with Extraluminal Device, Percutaneous Endoscopic Approach",
            "created_at": "2022-03-11T23:25:10.638Z",
            "updated_at": "2022-03-11T23:25:10.638Z",
            "__v": 0
        },
        {
            "image": "http://dummyimage.com/400x200.png/5fa2dd/ffffff",
            "likes": [],
            "comments": [],
            "tags": [
                "kaif"
            ],
            "isPublished": true,
            "_id": "622bda5c06c7d323b8ae4617",
            "title": "Winnie the Pooh and the Honey Tree",
            "author": {
                "name": "Иван Иванов",
                "about": "Писатель",
                "avatar": "https://react-learning.ru/image-compressed/default-image.jpg",
                "_id": "622bd81b06c7d323b8ae4614",
                "email": "maxim_91@inbox.ru",
                "__v": 0
            },
            "text": "Detachment at Left 1st Toe, Complete, Open Approach",
            "created_at": "2022-03-11T23:25:16.132Z",
            "updated_at": "2022-03-11T23:25:16.132Z",
            "__v": 0
        },
        {
            "image": "http://dummyimage.com/400x200.png/cc0000/ffffff",
            "likes": [],
            "comments": [],
            "tags": [
                "legendary"
            ],
            "isPublished": true,
            "_id": "622bda6106c7d323b8ae4618",
            "title": "Born on the Fourth of July",
            "author": {
                "name": "Иван Иванов",
                "about": "Писатель",
                "avatar": "https://react-learning.ru/image-compressed/default-image.jpg",
                "_id": "622bd81b06c7d323b8ae4614",
                "email": "maxim_91@inbox.ru",
                "__v": 0
            },
            "text": "Revision of Internal Fixation Device in Left Metatarsal-Tarsal Joint, Percutaneous Endoscopic Approach",
            "created_at": "2022-03-11T23:25:21.283Z",
            "updated_at": "2022-03-11T23:25:21.283Z",
            "__v": 0
        },
        {
            "image": "http://dummyimage.com/400x200.png/cc0000/ffffff",
            "likes": [],
            "comments": [],
            "tags": [
                "peace"
            ],
            "isPublished": true,
            "_id": "622bda6606c7d323b8ae4619",
            "title": "Alpha and Omega 3: The Great Wolf Games",
            "author": {
                "name": "Иван Иванов",
                "about": "Писатель",
                "avatar": "https://react-learning.ru/image-compressed/default-image.jpg",
                "_id": "622bd81b06c7d323b8ae4614",
                "email": "maxim_91@inbox.ru",
                "__v": 0
            },
            "text": "Replacement of Tricuspid Valve with Synthetic Substitute, Percutaneous Endoscopic Approach",
            "created_at": "2022-03-11T23:25:26.903Z",
            "updated_at": "2022-03-11T23:25:26.903Z",
            "__v": 0
        },
        {
            "image": "http://dummyimage.com/400x200.png/dddddd/000000",
            "likes": [],
            "comments": [],
            "tags": [
                "kaif"
            ],
            "isPublished": true,
            "_id": "622bda6b06c7d323b8ae461a",
            "title": "Full Moon in Paris (Les nuits de la pleine lune)",
            "author": {
                "name": "Иван Иванов",
                "about": "Писатель",
                "avatar": "https://react-learning.ru/image-compressed/default-image.jpg",
                "_id": "622bd81b06c7d323b8ae4614",
                "email": "maxim_91@inbox.ru",
                "__v": 0
            },
            "text": "Destruction of Left External Jugular Vein, Percutaneous Endoscopic Approach",
            "created_at": "2022-03-11T23:25:31.657Z",
            "updated_at": "2022-03-11T23:25:31.657Z",
            "__v": 0
        },
        {
            "image": "http://dummyimage.com/400x200.png/ff4444/ffffff",
            "likes": [],
            "comments": [],
            "tags": [
                "legendary"
            ],
            "isPublished": true,
            "_id": "622bda6f06c7d323b8ae461b",
            "title": "Secret Reunion (Ui-hyeong-je)",
            "author": {
                "name": "Иван Иванов",
                "about": "Писатель",
                "avatar": "https://react-learning.ru/image-compressed/default-image.jpg",
                "_id": "622bd81b06c7d323b8ae4614",
                "email": "maxim_91@inbox.ru",
                "__v": 0
            },
            "text": "Revision of Synthetic Substitute in Left Tarsal, Open Approach",
            "created_at": "2022-03-11T23:25:35.805Z",
            "updated_at": "2022-03-11T23:25:35.805Z",
            "__v": 0
        },
        {
            "image": "http://dummyimage.com/400x200.png/dddddd/000000",
            "likes": [],
            "comments": [],
            "tags": [
                "peace"
            ],
            "isPublished": true,
            "_id": "622bda7406c7d323b8ae461c",
            "title": "Shirin",
            "author": {
                "name": "Иван Иванов",
                "about": "Писатель",
                "avatar": "https://react-learning.ru/image-compressed/default-image.jpg",
                "_id": "622bd81b06c7d323b8ae4614",
                "email": "maxim_91@inbox.ru",
                "__v": 0
            },
            "text": "Revision of Synthetic Substitute in Right Rib, Open Approach",
            "created_at": "2022-03-11T23:25:40.052Z",
            "updated_at": "2022-03-11T23:25:40.052Z",
            "__v": 0
        },
        {
            "image": "http://dummyimage.com/400x200.png/dddddd/000000",
            "likes": [],
            "comments": [],
            "tags": [
                "kaif"
            ],
            "isPublished": true,
            "_id": "622bda7806c7d323b8ae461d",
            "title": "Restaurant",
            "author": {
                "name": "Иван Иванов",
                "about": "Писатель",
                "avatar": "https://react-learning.ru/image-compressed/default-image.jpg",
                "_id": "622bd81b06c7d323b8ae4614",
                "email": "maxim_91@inbox.ru",
                "__v": 0
            },
            "text": "Occlusion of Carina, Open Approach",
            "created_at": "2022-03-11T23:25:44.603Z",
            "updated_at": "2022-03-11T23:25:44.603Z",
            "__v": 0
        },
        {
            "image": "http://dummyimage.com/400x200.png/cc0000/ffffff",
            "likes": [],
            "comments": [],
            "tags": [
                "legendary"
            ],
            "isPublished": true,
            "_id": "622bda7c06c7d323b8ae461e",
            "title": "Little Richard",
            "author": {
                "name": "Иван Иванов",
                "about": "Писатель",
                "avatar": "https://react-learning.ru/image-compressed/default-image.jpg",
                "_id": "622bd81b06c7d323b8ae4614",
                "email": "maxim_91@inbox.ru",
                "__v": 0
            },
            "text": "Supplement Left Clavicle with Nonautologous Tissue Substitute, Percutaneous Endoscopic Approach",
            "created_at": "2022-03-11T23:25:48.921Z",
            "updated_at": "2022-03-11T23:25:48.921Z",
            "__v": 0
        },
        {
            "image": "http://dummyimage.com/400x200.png/ff4444/ffffff",
            "likes": [],
            "comments": [],
            "tags": [
                "peace"
            ],
            "isPublished": true,
            "_id": "622bda8406c7d323b8ae461f",
            "title": "Last Rites of Joe May, The",
            "author": {
                "name": "Иван Иванов",
                "about": "Писатель",
                "avatar": "https://react-learning.ru/image-compressed/default-image.jpg",
                "_id": "622bd81b06c7d323b8ae4614",
                "email": "maxim_91@inbox.ru",
                "__v": 0
            },
            "text": "Revision of Nonautologous Tissue Substitute in Lower Jaw, Open Approach",
            "created_at": "2022-03-11T23:25:56.906Z",
            "updated_at": "2022-03-11T23:25:56.906Z",
            "__v": 0
        },
        {
            "image": "http://dummyimage.com/400x200.png/5fa2dd/ffffff",
            "likes": [],
            "comments": [],
            "tags": [
                "kaif"
            ],
            "isPublished": true,
            "_id": "622bda8906c7d323b8ae4620",
            "title": "Crazy/Beautiful",
            "author": {
                "name": "Иван Иванов",
                "about": "Писатель",
                "avatar": "https://react-learning.ru/image-compressed/default-image.jpg",
                "_id": "622bd81b06c7d323b8ae4614",
                "email": "maxim_91@inbox.ru",
                "__v": 0
            },
            "text": "Therapeutic Exercise Treatment of Integumentary System - Lower Back / Lower Extremity using Prosthesis",
            "created_at": "2022-03-11T23:26:01.343Z",
            "updated_at": "2022-03-11T23:26:01.343Z",
            "__v": 0
        },
        {
            "image": "http://dummyimage.com/400x200.png/5fa2dd/ffffff",
            "likes": [],
            "comments": [],
            "tags": [
                "legendary"
            ],
            "isPublished": true,
            "_id": "622bda8e06c7d323b8ae4621",
            "title": "Kounterfeit",
            "author": {
                "name": "Иван Иванов",
                "about": "Писатель",
                "avatar": "https://react-learning.ru/image-compressed/default-image.jpg",
                "_id": "622bd81b06c7d323b8ae4614",
                "email": "maxim_91@inbox.ru",
                "__v": 0
            },
            "text": "Restriction of Right Hypogastric Vein with Intraluminal Device, Percutaneous Endoscopic Approach",
            "created_at": "2022-03-11T23:26:06.582Z",
            "updated_at": "2022-03-11T23:26:06.582Z",
            "__v": 0
        },
        {
            "image": "http://dummyimage.com/400x200.png/5fa2dd/ffffff",
            "likes": [],
            "comments": [],
            "tags": [
                "peace"
            ],
            "isPublished": true,
            "_id": "622bda9306c7d323b8ae4622",
            "title": "Nickelodeon",
            "author": {
                "name": "Иван Иванов",
                "about": "Писатель",
                "avatar": "https://react-learning.ru/image-compressed/default-image.jpg",
                "_id": "622bd81b06c7d323b8ae4614",
                "email": "maxim_91@inbox.ru",
                "__v": 0
            },
            "text": "Excision of Pineal Body, Open Approach",
            "created_at": "2022-03-11T23:26:11.496Z",
            "updated_at": "2022-03-11T23:26:11.496Z",
            "__v": 0
        },
        {
            "image": "http://dummyimage.com/400x200.png/5fa2dd/ffffff",
            "likes": [],
            "comments": [],
            "tags": [
                "kaif"
            ],
            "isPublished": true,
            "_id": "622bda9706c7d323b8ae4623",
            "title": "Great Flamarion, The",
            "author": {
                "name": "Иван Иванов",
                "about": "Писатель",
                "avatar": "https://react-learning.ru/image-compressed/default-image.jpg",
                "_id": "622bd81b06c7d323b8ae4614",
                "email": "maxim_91@inbox.ru",
                "__v": 0
            },
            "text": "Supplement Right Kidney Pelvis with Nonautologous Tissue Substitute, Percutaneous Endoscopic Approach",
            "created_at": "2022-03-11T23:26:15.852Z",
            "updated_at": "2022-03-11T23:26:15.852Z",
            "__v": 0
        },
        {
            "image": "http://dummyimage.com/400x200.png/cc0000/ffffff",
            "likes": [],
            "comments": [],
            "tags": [
                "legendary"
            ],
            "isPublished": true,
            "_id": "622bda9c06c7d323b8ae4624",
            "title": "Guy Thing, A",
            "author": {
                "name": "Иван Иванов",
                "about": "Писатель",
                "avatar": "https://react-learning.ru/image-compressed/default-image.jpg",
                "_id": "622bd81b06c7d323b8ae4614",
                "email": "maxim_91@inbox.ru",
                "__v": 0
            },
            "text": "Tomographic (Tomo) Nuclear Medicine Imaging of Pelvic Region using Iodine 131 (I-131)",
            "created_at": "2022-03-11T23:26:20.673Z",
            "updated_at": "2022-03-11T23:26:20.673Z",
            "__v": 0
        },
        {
            "image": "http://dummyimage.com/400x200.png/ff4444/ffffff",
            "likes": [],
            "comments": [],
            "tags": [
                "peace"
            ],
            "isPublished": true,
            "_id": "622bdaa106c7d323b8ae4625",
            "title": "The Facility",
            "author": {
                "name": "Иван Иванов",
                "about": "Писатель",
                "avatar": "https://react-learning.ru/image-compressed/default-image.jpg",
                "_id": "622bd81b06c7d323b8ae4614",
                "email": "maxim_91@inbox.ru",
                "__v": 0
            },
            "text": "Revision of Other Device in Neck, Open Approach",
            "created_at": "2022-03-11T23:26:25.051Z",
            "updated_at": "2022-03-11T23:26:25.051Z",
            "__v": 0
        },
        {
            "image": "http://dummyimage.com/400x200.png/dddddd/000000",
            "likes": [],
            "comments": [],
            "tags": [
                "kaif"
            ],
            "isPublished": true,
            "_id": "622bdaa406c7d323b8ae4626",
            "title": "Transit",
            "author": {
                "name": "Иван Иванов",
                "about": "Писатель",
                "avatar": "https://react-learning.ru/image-compressed/default-image.jpg",
                "_id": "622bd81b06c7d323b8ae4614",
                "email": "maxim_91@inbox.ru",
                "__v": 0
            },
            "text": "Low Dose Rate (LDR) Brachytherapy of Jejunum using Other Isotope",
            "created_at": "2022-03-11T23:26:28.656Z",
            "updated_at": "2022-03-11T23:26:28.656Z",
            "__v": 0
        },
        {
            "image": "http://dummyimage.com/400x200.png/ff4444/ffffff",
            "likes": [],
            "comments": [],
            "tags": [
                "legendary"
            ],
            "isPublished": true,
            "_id": "622bdab806c7d323b8ae4627",
            "title": "Blackboards (Takhté Siah)",
            "author": {
                "name": "Иван Иванов",
                "about": "Писатель",
                "avatar": "https://react-learning.ru/image-compressed/default-image.jpg",
                "_id": "622bd81b06c7d323b8ae4614",
                "email": "maxim_91@inbox.ru",
                "__v": 0
            },
            "text": "Insertion of External Fixation Device into Right Acetabulum, Open Approach",
            "created_at": "2022-03-11T23:26:48.849Z",
            "updated_at": "2022-03-11T23:26:48.849Z",
            "__v": 0
        },
        {
            "image": "http://dummyimage.com/400x200.png/cc0000/ffffff",
            "likes": [],
            "comments": [],
            "tags": [
                "peace"
            ],
            "isPublished": true,
            "_id": "622bdabc06c7d323b8ae4628",
            "title": "Blood and Sand (Sangre y Arena)",
            "author": {
                "name": "Иван Иванов",
                "about": "Писатель",
                "avatar": "https://react-learning.ru/image-compressed/default-image.jpg",
                "_id": "622bd81b06c7d323b8ae4614",
                "email": "maxim_91@inbox.ru",
                "__v": 0
            },
            "text": "Removal of Nonautologous Tissue Substitute from Penis, Open Approach",
            "created_at": "2022-03-11T23:26:52.740Z",
            "updated_at": "2022-03-11T23:26:52.740Z",
            "__v": 0
        },
        {
            "image": "http://dummyimage.com/400x200.png/cc0000/ffffff",
            "likes": [],
            "comments": [],
            "tags": [
                "kaif"
            ],
            "isPublished": true,
            "_id": "622bdac006c7d323b8ae4629",
            "title": "Heavy",
            "author": {
                "name": "Иван Иванов",
                "about": "Писатель",
                "avatar": "https://react-learning.ru/image-compressed/default-image.jpg",
                "_id": "622bd81b06c7d323b8ae4614",
                "email": "maxim_91@inbox.ru",
                "__v": 0
            },
            "text": "Repair Left Common Carotid Artery, Percutaneous Approach",
            "created_at": "2022-03-11T23:26:56.577Z",
            "updated_at": "2022-03-11T23:26:56.577Z",
            "__v": 0
        },
        {
            "image": "http://dummyimage.com/400x200.png/5fa2dd/ffffff",
            "likes": [],
            "comments": [],
            "tags": [
                "peace"
            ],
            "isPublished": true,
            "_id": "622bdad206c7d323b8ae462a",
            "title": "Star Trek VI: The Undiscovered Country",
            "author": {
                "name": "Иван Иванов",
                "about": "Писатель",
                "avatar": "https://react-learning.ru/image-compressed/default-image.jpg",
                "_id": "622bd81b06c7d323b8ae4614",
                "email": "maxim_91@inbox.ru",
                "__v": 0
            },
            "text": "Revision of Synthetic Substitute in Male Perineum, Open Approach",
            "created_at": "2022-03-11T23:27:14.683Z",
            "updated_at": "2022-03-11T23:27:14.683Z",
            "__v": 0
        },
        {
            "image": "http://dummyimage.com/400x200.png/cc0000/ffffff",
            "likes": [],
            "comments": [],
            "tags": [
                "kaif"
            ],
            "isPublished": true,
            "_id": "622bdad606c7d323b8ae462b",
            "title": "Ankur (The Seedling)",
            "author": {
                "name": "Иван Иванов",
                "about": "Писатель",
                "avatar": "https://react-learning.ru/image-compressed/default-image.jpg",
                "_id": "622bd81b06c7d323b8ae4614",
                "email": "maxim_91@inbox.ru",
                "__v": 0
            },
            "text": "Excision of Thoracolumbar Vertebral Disc, Percutaneous Approach, Diagnostic",
            "created_at": "2022-03-11T23:27:18.401Z",
            "updated_at": "2022-03-11T23:27:18.401Z",
            "__v": 0
        },
        {
            "image": "http://dummyimage.com/400x200.png/cc0000/ffffff",
            "likes": [],
            "comments": [],
            "tags": [
                "legendary"
            ],
            "isPublished": true,
            "_id": "622bdada06c7d323b8ae462c",
            "title": "Love Me If You Dare (Jeux d'enfants)",
            "author": {
                "name": "Иван Иванов",
                "about": "Писатель",
                "avatar": "https://react-learning.ru/image-compressed/default-image.jpg",
                "_id": "622bd81b06c7d323b8ae4614",
                "email": "maxim_91@inbox.ru",
                "__v": 0
            },
            "text": "Excision of Face Skin, External Approach",
            "created_at": "2022-03-11T23:27:22.077Z",
            "updated_at": "2022-03-11T23:27:22.077Z",
            "__v": 0
        },
        {
            "image": "http://dummyimage.com/400x200.png/cc0000/ffffff",
            "likes": [],
            "comments": [],
            "tags": [
                "peace"
            ],
            "isPublished": true,
            "_id": "622bdade06c7d323b8ae462d",
            "title": "Scoop",
            "author": {
                "name": "Иван Иванов",
                "about": "Писатель",
                "avatar": "https://react-learning.ru/image-compressed/default-image.jpg",
                "_id": "622bd81b06c7d323b8ae4614",
                "email": "maxim_91@inbox.ru",
                "__v": 0
            },
            "text": "Restriction of Left Hepatic Duct with Intraluminal Device, Via Natural or Artificial Opening Endoscopic",
            "created_at": "2022-03-11T23:27:26.110Z",
            "updated_at": "2022-03-11T23:27:26.110Z",
            "__v": 0
        },
        {
            "image": "http://dummyimage.com/400x200.png/dddddd/000000",
            "likes": [],
            "comments": [],
            "tags": [
                "kaif"
            ],
            "isPublished": true,
            "_id": "622bdae106c7d323b8ae462e",
            "title": "Duel at Diablo",
            "author": {
                "name": "Иван Иванов",
                "about": "Писатель",
                "avatar": "https://react-learning.ru/image-compressed/default-image.jpg",
                "_id": "622bd81b06c7d323b8ae4614",
                "email": "maxim_91@inbox.ru",
                "__v": 0
            },
            "text": "Drainage of Lumbar Vertebral Joint, Percutaneous Endoscopic Approach",
            "created_at": "2022-03-11T23:27:29.583Z",
            "updated_at": "2022-03-11T23:27:29.583Z",
            "__v": 0
        },
        {
            "image": "http://dummyimage.com/400x200.png/dddddd/000000",
            "likes": [],
            "comments": [],
            "tags": [
                "legendary"
            ],
            "isPublished": true,
            "_id": "622bdae406c7d323b8ae462f",
            "title": "Target Shoots First, The",
            "author": {
                "name": "Иван Иванов",
                "about": "Писатель",
                "avatar": "https://react-learning.ru/image-compressed/default-image.jpg",
                "_id": "622bd81b06c7d323b8ae4614",
                "email": "maxim_91@inbox.ru",
                "__v": 0
            },
            "text": "Monitoring of Cardiac Output, External Approach",
            "created_at": "2022-03-11T23:27:32.669Z",
            "updated_at": "2022-03-11T23:27:32.669Z",
            "__v": 0
        },
        {
            "image": "http://dummyimage.com/400x200.png/ff4444/ffffff",
            "likes": [],
            "comments": [],
            "tags": [
                "peace"
            ],
            "isPublished": true,
            "_id": "622bdae806c7d323b8ae4630",
            "title": "First Case, Second Case (Ghazieh-e Shekl-e Aval, Ghazieh-e Shekl-e Dou Wom)",
            "author": {
                "name": "Иван Иванов",
                "about": "Писатель",
                "avatar": "https://react-learning.ru/image-compressed/default-image.jpg",
                "_id": "622bd81b06c7d323b8ae4614",
                "email": "maxim_91@inbox.ru",
                "__v": 0
            },
            "text": "Reposition Left Sphenoid Bone, Percutaneous Endoscopic Approach",
            "created_at": "2022-03-11T23:27:36.313Z",
            "updated_at": "2022-03-11T23:27:36.313Z",
            "__v": 0
        }
    ];
