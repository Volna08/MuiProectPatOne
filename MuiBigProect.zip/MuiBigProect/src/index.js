import React from "react";
import ReactDOM from "react-dom";


import {AppMui} from "./AppMui"

ReactDOM.render(<AppMui/>, document.querySelector('#root'));


insertPub.onclick = function(event) {
// alert("Есть контакт");
console.log("Есть контакт")
};