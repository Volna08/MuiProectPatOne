import React from "react";
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import { Avatar, Grid } from "@mui/material";
import { Divider } from "@mui/material";
import Stack from '@mui/material/Stack';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField'
import "./styles.css"
import { blue, blueGrey, green } from "@mui/material/colors";
import dayjs, { Dayjs } from "dayjs";



function stringToColor(string) {
  let hash = 0;
  let i;
  /* eslint-disable no-bitwise */
  for (i = 0; i < string.length; i += 1) {
    hash = string.charCodeAt(i) + ((hash << 5) - hash);
  }
  let color = '#';
  for (i = 0; i < 3; i += 1) {
    const value = (hash >> (i * 8)) & 0xff;
    color += `00${value.toString(16)}`.substr(-2);
  }
  /* eslint-enable no-bitwise */
  return color;
}
function stringAvatar(name) {
  return {
    sx: {
      bgcolor: stringToColor(name),
    },
    children: `${name.split(' ')[0][0]}${name.split(' ')[1][0]}`,
  };
}


export const Post = ({ image, tags, title, text, author: { name, email, avatar }, created_at }) => {

  const dataFormated = dayjs(created_at).format('M/D/YYYY')
  
  return (
    <Grid container item xs={6} sm={4} md={3}>
      <Card className = "mainCard" sx={{ maxWidth: 365, margin: 2 }}>
        {/* бордер не работает */}
        <CardContent>
          <Typography gutterBottom variant="h5" component="div" >
            {title}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            {dataFormated}
          </Typography>
        </CardContent>
        <Divider />

        {/* <Typography variant="h6" component="div">
        <Avatar alt={email} src={avatar} />
          {email}
        </Typography> */}
        <CardContent>
          <Stack direction="row" spacing={2}>
            <Typography variant="h6" component="span">
              <Avatar {...stringAvatar(name)} />
              <Typography variant="h6" component="span">
                                {email}
              </Typography> 
                          </Typography>
          </Stack>
          <Divider />

          <Typography variant="body2" color="text.secondary">
            {text}
          </Typography>
        </CardContent>

        <Divider />
        <div className="tagsContainer">
  <div className="item">Tags:  </div>
  <div className="itemLine">{tags}</div>
</div>
</Card>
   </Grid>     
    
  )
}